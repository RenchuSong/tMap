package com.tmap_android_client.opengl;

import javax.microedition.khronos.opengles.GL10;

public interface Geometry {
	public void drawSelf(GL10 gl);
}
