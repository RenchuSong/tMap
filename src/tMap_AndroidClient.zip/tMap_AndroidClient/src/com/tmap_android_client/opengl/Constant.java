package com.tmap_android_client.opengl;

public class Constant {
	 public static final float TEX_PER_METER = 3;
}

