package com.tmap_android_client.activities;

public interface SensorActivity {
	public abstract void SensorChanged(int id);
}
