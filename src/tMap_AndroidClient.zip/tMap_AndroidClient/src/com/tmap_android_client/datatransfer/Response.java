package com.tmap_android_client.datatransfer;

public class Response {
	public String response = null;
	public String exception = null;
	
}
