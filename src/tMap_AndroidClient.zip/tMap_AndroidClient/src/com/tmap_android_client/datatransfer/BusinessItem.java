package com.tmap_android_client.datatransfer;

public class BusinessItem {
	public int buildingId, floor;
	public float x, y;
	public String title, type, content, imageURL, extra;
}
