package com.tmap_android_client.datatransfer;

public class DirectorPoint {
	public float x, y, z;
}
