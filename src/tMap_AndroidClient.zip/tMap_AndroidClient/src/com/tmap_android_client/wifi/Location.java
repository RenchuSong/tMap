package com.tmap_android_client.wifi;

public class Location {
	public int buildingId, floor, x, y;
}
