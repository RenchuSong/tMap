package com.tmap_android_client.wifi;

public class WifiItem {
	public String name;
	public int magnitude;
	
	public WifiItem() {}
	
	public WifiItem(String name, int magnitude) {
		this.name = name;
		this.magnitude = magnitude;
	}
}
